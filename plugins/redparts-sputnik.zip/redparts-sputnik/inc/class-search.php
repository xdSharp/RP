<?php
/**
 * RedParts sputnik search.
 *
 * @package RedParts\Sputnik
 * @since 1.1.0
 * @noinspection SqlResolve
 */

namespace RedParts\Sputnik;

use RedParts\Sputnik\WPML\WPML;
use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Search' ) ) {
	/**
	 * Class Search.
	 *
	 * @package RedParts\Sputnik
	 */
	class Search extends Singleton {
		/**
		 * The name of the index build cursor option.
		 *
		 * @since 1.16.0
		 */
		const BUILD_INDEX_CURSOR_OPTION = 'redparts_sputnik_search_build_index_cursor';

		/**
		 * Initialization.
		 */
		public function init() {
			add_action( 'after_setup_theme', array( $this, 'deferred_init' ) );
			// Clear index after import.
			add_action( 'pt-ocdi/after_import', array( $this, 'clear_index' ), 20 );
		}

		/**
		 * Deferred initialization.
		 */
		public function deferred_init() {
			if ( ! class_exists( 'WooCommerce' ) ) {
				return;
			}

			add_action( 'init', array( $this, 'build_index' ), 1000 );
			add_action( 'save_post', array( $this, 'save_post' ), 10, 2 );
			add_action( 'wp_ajax_redparts_sputnik_search_index_status', array( $this, 'ajax_index_status' ) );
			add_action( 'wp_ajax_redparts_sputnik_search_clear_index', array( $this, 'ajax_clear_index' ) );

			add_action( 'wp_ajax_redparts_sputnik_search_suggestions', array( $this, 'ajax_search_suggestions' ) );
			add_action( 'wp_ajax_nopriv_redparts_sputnik_search_suggestions', array( $this, 'ajax_search_suggestions' ) );

			add_filter( 'posts_search', array( $this, 'wp_query_posts_search' ), 10, 2 );
			add_filter( 'posts_join', array( $this, 'wp_query_posts_join' ), 10, 2 );
		}

		/**
		 * Modifies search part of the WP_Query.
		 *
		 * @since 1.12.0
		 *
		 * @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection
		 *
		 * @param string   $search - Search part of the SQL query.
		 * @param WP_Query $query  - WordPress query object.
		 *
		 * @return string
		 */
		public function wp_query_posts_search( $search, $query ) {
			global $wpdb;

			$is_search_by_products = $query->is_search
				&& 'product' === $query->get( 'post_type' )
				&& ! empty( $query->query_vars['search_terms'] );

			if ( ! $is_search_by_products ) {
				return $search;
			}

			$terms = $query->query_vars['search_terms'];

			if ( 'yes' === Settings::instance()->get( 'search_by_sku' ) ) {
				$offset = 0;
				$i      = 0;

				while ( true ) {
					$example = "($wpdb->posts.post_title LIKE '";

					$pos = strpos( $search, $example, $offset );

					if ( false === $pos || ! isset( $terms[ $i ] ) ) {
						break;
					}

					$match_type = Settings::instance()->get( 'search_by_sku_match' );

					if ( 'starts' === $match_type ) {
						$value = $wpdb->esc_like( $terms[ $i ] ) . '%';
					} elseif ( 'contains' === $match_type ) {
						$value = '%' . $wpdb->esc_like( $terms[ $i ] ) . '%';
					} else {
						$value = $wpdb->esc_like( $terms[ $i ] );
					}

					$new = $wpdb->prepare( "(redparts_sputnik_si1.term LIKE %s AND redparts_sputnik_si1.source = 'sku') OR ($wpdb->posts.post_title LIKE '", $value );

					$search = substr_replace( $search, $new, $pos, strlen( $example ) );

					$offset = $pos + strlen( $new );
					++$i;
				}
			}

			$exact_match = (array) Settings::instance()->get( 'search_by_attributes' );
			$exact_match = array_map( 'wc_attribute_taxonomy_name', $exact_match );

			$starts_with = (array) Settings::instance()->get( 'search_by_attributes_starts' );
			$starts_with = array_map( 'wc_attribute_taxonomy_name', $starts_with );

			$contains = (array) Settings::instance()->get( 'search_by_attributes_contains' );
			$contains = array_map( 'wc_attribute_taxonomy_name', $contains );

			$attributes = array_merge(
				$exact_match,
				$starts_with,
				$contains
			);

			if ( ! empty( $attributes ) ) {
				$prepare_where = function( $attributes, $match_type ) use ( $wpdb, $terms ) {
					$sql_terms = array();

					foreach ( $terms as $term ) {
						if ( 'starts' === $match_type ) {
							$value = $wpdb->esc_like( $term ) . '%';
						} elseif ( 'contains' === $match_type ) {
							$value = '%' . $wpdb->esc_like( $term ) . '%';
						} else {
							$value = $wpdb->esc_like( $term );
						}

						$sql_terms[] = $wpdb->prepare( 't.name LIKE %s', $value );
					}

					$sql_terms  = implode( ' OR ', $sql_terms );
					$taxonomies = $attributes;

					$taxonomies = array_map(
						function( $taxonomy ) use ( $wpdb ) {
							return $wpdb->prepare( '%s', $taxonomy );
						},
						$taxonomies
					);
					$taxonomies = implode( ', ', $taxonomies );

					return "(($sql_terms) AND tt.taxonomy IN ($taxonomies))";
				};

				$where = array();

				if ( ! empty( $exact_match ) ) {
					$where[] = $prepare_where( $exact_match, 'exactly' );
				}
				if ( ! empty( $starts_with ) ) {
					$where[] = $prepare_where( $starts_with, 'starts' );
				}
				if ( ! empty( $contains ) ) {
					$where[] = $prepare_where( $contains, 'contains' );
				}

				$where = implode( ' OR ', $where );

				$append = "
					$wpdb->posts.ID IN (
						SELECT DISTINCT
							tr.object_id
						FROM $wpdb->terms AS t
						INNER JOIN $wpdb->term_taxonomy AS tt ON t.term_id = tt.term_id
						INNER JOIN $wpdb->term_relationships AS tr ON tt.term_taxonomy_id = tr.term_taxonomy_id
						WHERE 1 = 1
							AND ($where)
					)
				";

				$append = empty( $append ) ? $append : "($append) OR ";

				$search = str_replace( ')))', '))))', $search );
				$search = str_replace( '(((', "($append(((", $search );
			}

			return $search;
		}

		/**
		 * Modifies JOIN clause of the WP_Query.
		 *
		 * @since 1.12.0
		 *
		 * @noinspection PhpMissingParamTypeInspection,PhpMissingReturnTypeInspection
		 *
		 * @param string   $join  - Join clause.
		 * @param WP_Query $query - WordPress query object.
		 *
		 * @return string
		 */
		public function wp_query_posts_join( $join, $query ) {
			global $wpdb;

			$is_search_by_products = $query->is_search
				&& 'product' === $query->get( 'post_type' )
				&& ! empty( $query->query_vars['search_terms'] );

			if ( ! $is_search_by_products ) {
				return $join;
			}

			if ( 'yes' === Settings::instance()->get( 'search_by_sku' ) ) {
				$join = $join . " LEFT JOIN {$wpdb->prefix}redparts_sputnik_search_index AS redparts_sputnik_si1 ON redparts_sputnik_si1.post_id = $wpdb->posts.ID";
			}

			return $join;
		}

		/**
		 * Modifies search query.
		 *
		 * @deprecated since 1.12.0 and will be removed from version 2.0.0.
		 *
		 * @param WP_Query $query Query object.
		 */
		public function pre_get_posts( WP_Query $query ) { }

		/**
		 * Returns the replaced search query if it was modified using the pre_get_posts hook.
		 *
		 * @deprecated since 1.12.0 and will be removed from version 2.0.0.
		 *
		 * @param string $default Default search query.
		 *
		 * @return string
		 */
		public function get_search_query( string $default ): string {
			return $default;
		}

		/**
		 * Output search suggestions.
		 */
		public function ajax_search_suggestions() {
			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['nonce'] ) ), 'redparts_sputnik_search_suggestions' )
			) {
				wp_send_json_error();
				return;
			}

			WPML::switch_ajax_language();

			if ( ! isset( $_POST['id'] ) || ! isset( $_POST['s'] ) ) {
				wp_send_json_error();
				return;
			}

			$form_id = sanitize_text_field( wp_unslash( $_POST['id'] ) );
			$s       = sanitize_text_field( wp_unslash( $_POST['s'] ) );

			$query_args = array(
				's'              => $s,
				'sentence'       => false,
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 20,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'tax_query'      => array(
					'relation' => 'AND',
				),
			);

			$link_args = array(
				'post_type' => 'product',
				's'         => $s,
			);

			$query_args['tax_query'][] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => array( 'exclude-from-search' ),
				'operator' => 'NOT IN',
			);

			if ( ! empty( $_POST['redparts_taxonomy'] ) && ! empty( $_POST['redparts_taxonomy_value'] ) ) {
				$taxonomy       = sanitize_key( wp_unslash( $_POST['redparts_taxonomy'] ) );
				$taxonomy_value = sanitize_text_field( wp_unslash( $_POST['redparts_taxonomy_value'] ) );
				$taxonomy_terms = array();

				if ( Vehicles::instance()->get_attribute_slug() === $taxonomy ) {
					if ( preg_match( '#^[0-9]+$#', $taxonomy_value ) ) {
						$vehicle = Vehicles::instance()->get_vehicle_by_id( absint( $taxonomy_value ) );
					} else {
						$vehicle = Vehicles::instance()->get_vehicle_by_instance_id( $taxonomy_value );
					}

					if ( $vehicle ) {
						$taxonomy_terms   = is_array( $vehicle['slug'] ) ? $vehicle['slug'] : array( $vehicle['slug'] );
						$taxonomy_terms[] = Vehicles::instance()->get_all_term_slug();

						$query_arg_name  = Vehicles::instance()->get_attribute_filter_name();
						$query_arg_value = Vehicles::instance()->get_attribute_filter_value( $vehicle );

						$link_args[ $query_arg_name ] = $query_arg_value;
					}
				} else {
					$taxonomy_terms = array( sanitize_key( $taxonomy_value ) );

					$link_args[ $taxonomy ] = $taxonomy_value;
				}

				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				$query_args['tax_query'][] = array(
					'taxonomy' => $taxonomy,
					'field'    => 'slug',
					'terms'    => $taxonomy_terms,
				);
			}

			$query = new WP_Query( $query_args );

			foreach ( $query->posts as $product ) {
				$query->setup_postdata( $product );
				?>
				<a
					href="<?php echo esc_url( get_the_permalink( $product ) ); ?>"
					class="th-suggestions__item th-suggestions__item--product th-suggestions__product"
					tabindex="-1"
					role="option"
					id="<?php echo esc_attr( $form_id . '-suggestions-option-product-' . $product->ID ); ?>"
					data-s="<?php echo esc_attr( wp_kses( get_the_title( $product ), array() ) ); ?>"
				>
					<div class="th-suggestions__product-image">
						<?php echo wp_kses( woocommerce_get_product_thumbnail( array( 44, 44 ) ), 'redparts_sputnik_image' ); ?>
					</div>
					<div class="th-suggestions__product-info">
						<div class="th-suggestions__product-name">
							<?php
							echo wp_kses_post(
								preg_replace(
									'/' . preg_quote( $s, '/' ) . '/i',
									'<strong>$0</strong>',
									get_the_title( $product )
								)
							);
							?>
						</div>
						<div class="th-suggestions__product-price th-price">
							<?php woocommerce_template_loop_price(); ?>
						</div>
					</div>
				</a>
				<?php
			}
			$query->reset_postdata();

			if ( $query->found_posts > $query->post_count ) {
				$link = add_query_arg( $link_args, home_url( '/' ) );

				?>
				<a
					href="<?php echo esc_url( $link ); ?>"
					class="th-suggestions__item th-suggestions__item--all-results"
					tabindex="-1"
					role="option"
					id="<?php echo esc_attr( $form_id . '-suggestions-option-all-results' ); ?>"
					data-s="<?php echo esc_attr( $s ); ?>"
				>
					<?php echo esc_html__( 'See all results', 'redparts-sputnik' ); ?>
				</a>
				<?php
			}

			wp_die();
		}

		/**
		 * Builds a search index.
		 *
		 * @since 1.16.0
		 */
		public function build_index() {
			global $wpdb;

			$limit = (int) apply_filters( 'redparts_sputnik_search_build_index_limit', 50 );
			$limit = max( 1, $limit );

			if ( version_compare( Database::version(), '1.16.0', '<' ) ) {
				return;
			}

			$cursor = get_option( self::BUILD_INDEX_CURSOR_OPTION, '0' );

			if ( 'end' !== $cursor ) {
				$cursor = (int) $cursor;

				$sql = $wpdb->prepare(
					"
						SELECT p.ID
						FROM $wpdb->posts AS p
						WHERE
							p.post_type = 'product' AND
							p.ID > %d
						ORDER BY p.ID
						LIMIT 0, %d
					",
					$cursor,
					$limit
				);

				// phpcs:disable WordPress.DB.DirectDatabaseQuery
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
				$product_ids = $wpdb->get_col( $sql );
				// phpcs:enable

				$this->build_products_index( $product_ids );

				if ( 0 === count( $product_ids ) ) {
					$cursor = 'end';
				} else {
					$cursor = $product_ids[ count( $product_ids ) - 1 ];
				}

				update_option( self::BUILD_INDEX_CURSOR_OPTION, $cursor );
			}
		}

		/**
		 * Indexes products.
		 *
		 * @since 1.16.0
		 *
		 * @param int[] $product_ids Array of products.
		 */
		public function build_products_index( array $product_ids ) {
			global $wpdb;

			if ( version_compare( Database::version(), '1.16.0', '<' ) ) {
				return;
			}

			$product_ids = wp_parse_id_list( $product_ids );

			if ( 0 === count( $product_ids ) ) {
				return;
			}

			$product_ids = implode( ', ', $product_ids );

			$sql = "
			DELETE FROM {$wpdb->prefix}redparts_sputnik_search_index
			WHERE post_id IN ($product_ids)
			";

			// phpcs:disable WordPress.DB.DirectDatabaseQuery
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( $sql );
			// phpcs:enable

			$sql = "
			INSERT INTO {$wpdb->prefix}redparts_sputnik_search_index (post_id, term, source)
			SELECT DISTINCT
				IF(p.post_parent = 0, p.ID, p.post_parent),
				pm.meta_value,
				'sku'
			FROM $wpdb->posts AS p
			LEFT JOIN $wpdb->postmeta AS pm ON
				pm.post_id = p.ID AND
				pm.meta_key = '_sku'
			WHERE
				p.post_type IN ('product', 'product_variation') AND
				pm.meta_value IS NOT NULL AND
			    (
					p.ID IN ($product_ids) OR
					p.post_parent IN ($product_ids)
				)
			";

			// phpcs:disable WordPress.DB.DirectDatabaseQuery
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( $sql );
			// phpcs:enable
		}

		/**
		 * Starts product indexing on save.
		 *
		 * @noinspection PhpMissingParamTypeInspection
		 *
		 * @since 1.16.0
		 *
		 * @param int     $post_id Post ID.
		 * @param WP_Post $post    Post object.
		 */
		public function save_post( $post_id, $post ) {
			if ( 'product' !== $post->post_type ) {
				return;
			}

			$this->build_products_index( array( $post_id ) );
		}

		/**
		 * Returns the indexing status.
		 *
		 * @since 1.16.0
		 *
		 * @return array
		 */
		public function index_status(): array {
			global $wpdb;

			$sql = "
				SELECT COUNT(p.ID)
				FROM $wpdb->posts AS p
				WHERE p.post_type = 'product'
			";

			// phpcs:disable WordPress.DB.DirectDatabaseQuery
			// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
			// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
			$total_products = (int) $wpdb->get_var( $sql );
			// phpcs:enable

			$cursor = get_option( self::BUILD_INDEX_CURSOR_OPTION, '0' );

			if ( 'end' !== $cursor ) {
				$cursor = (int) $cursor;

				$sql = $wpdb->prepare(
					"
						SELECT COUNT(p.ID)
						FROM $wpdb->posts AS p
						WHERE
							p.post_type = 'product' AND
							p.ID > %d
						ORDER BY p.ID
					",
					$cursor
				);

				// phpcs:disable WordPress.DB.DirectDatabaseQuery
				// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching
				// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared
				$remaining_products = (int) $wpdb->get_var( $sql );
				// phpcs:enable
			} else {
				$remaining_products = 0;
			}

			return array(
				'total_products'   => $total_products,
				'indexed_products' => $total_products - $remaining_products,
			);
		}

		/**
		 * Returns the status of the search index.
		 *
		 * @since 1.17.0
		 */
		public function ajax_index_status() {
			if (
				! isset( $_GET['nonce'] ) ||
				! wp_verify_nonce( sanitize_key( wp_unslash( $_GET['nonce'] ) ), 'redparts_sputnik_search_index_status' )
			) {
				wp_send_json_error();
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error();
			}

			$status = $this->index_status();

			if ( 0 === $status['total_products'] ) {
				$status_text = esc_html__( 'There are no products to index.', 'redparts-sputnik' );
			} elseif ( $status['total_products'] === $status['indexed_products'] ) {
				$status_text = esc_html__( 'All products are indexed.', 'redparts-sputnik' );
			} else {
				$status_text = sprintf(
				/* translators: 1: Indexed products, 2: Total products, 3: Percent of indexed products. */
					_n( 'Indexed %1$d of %2$d product (%3$.2f%%).', 'Indexed %1$d of %2$d products (%3$.2f%%).', $status['total_products'], 'redparts-sputnik' ),
					$status['indexed_products'],
					$status['total_products'],
					( $status['indexed_products'] / $status['total_products'] ) * 100
				);
			}

			wp_send_json_success(
				array_merge(
					$status,
					array( 'text' => $status_text )
				)
			);
		}

		/**
		 * Handles clear index AJAX request.
		 *
		 * @since 1.16.0
		 */
		public function ajax_clear_index() {
			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['nonce'] ) ), 'redparts_sputnik_search_clear_index' )
			) {
				wp_send_json_error();
			}

			if ( ! current_user_can( 'edit_posts' ) ) {
				wp_send_json_error();
			}

			$this->clear_index();

			wp_send_json_success();
		}

		/**
		 * Clear index.
		 *
		 * @since 1.16.0
		 */
		public function clear_index() {
			global $wpdb;

			if ( version_compare( Database::version(), '1.16.0', '<' ) ) {
				return;
			}

			delete_option( self::BUILD_INDEX_CURSOR_OPTION );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery
			$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}redparts_sputnik_search_index" );
			// phpcs:enable
		}
	}
}
