<?php
/**
 * RedParts sputnik settings.
 *
 * @package RedParts\Sputnik
 * @since 1.0.0
 */

namespace RedParts\Sputnik;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Settings' ) ) {
	/**
	 * Class Settings.
	 *
	 * @package RedParts\Sputnik
	 */
	class Settings extends Singleton {
		/**
		 * Initialization.
		 */
		public function init() { }

		/**
		 * Returns setting value.
		 *
		 * @since 1.17.0 this method is static.
		 *
		 * @param string $id      Setting ID.
		 * @param null   $default Default setting value.
		 *
		 * @return mixed
		 */
		public static function get( string $id, $default = null ) {
			return \RedParts\Sputnik\Scompiler\Settings::get( $id, $default );
		}

		/**
		 * Sets setting value.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id    Setting ID.
		 * @param mixed  $value Setting value.
		 *
		 * @return void
		 */
		public static function set( string $id, $value ): void {
			\RedParts\Sputnik\Scompiler\Settings::set( $id, $value );
		}
	}
}
