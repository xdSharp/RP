<?php
/**
 * RedParts sputnik settings.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler;

use RedParts\Sputnik\Singleton;
use stdClass;
use WP_Post;
use WP_Term;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Data' ) ) {
	/**
	 * Class Data.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Data extends Singleton {
		/**
		 * List of menu objects.
		 *
		 * @since 1.17.0
		 *
		 * @var WP_Term[]|null
		 */
		protected $menus = null;

		/**
		 * List of page objects.
		 *
		 * @since 1.17.0
		 *
		 * @var WP_Post[]|null
		 */
		protected $pages = null;

		/**
		 * List of product attribute objects.
		 *
		 * @since 1.17.0
		 *
		 * @var stdClass[]|null
		 */
		protected $product_attributes = null;

		/**
		 * Returns menu options.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function get_menus(): array {
			if ( null === $this->menus ) {
				$this->menus = wp_get_nav_menus();
			}

			return array_map(
				function( $menu ) {
					return array(
						// translators: %1$s menu name, %2$s menu ID.
						'title' => sprintf( esc_html__( '%1$s [%2$s]', 'redparts-sputnik' ), $menu->name, $menu->term_id ),
						'value' => (string) $menu->term_id,
					);
				},
				$this->menus
			);
		}

		/**
		 * Returns page options.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function get_pages(): array {
			if ( null === $this->pages ) {
				$this->pages = get_posts(
					array(
						'post_type'   => 'page',
						'post_status' => 'any',
						'nopaging'    => true,
					)
				);
			}

			return array_map(
				function( $page ) {
					return array(
						// translators: %1$s page title, %2$s page ID.
						'title' => sprintf( esc_html__( '%1$s [%2$s]', 'redparts-sputnik' ), $page->post_title, $page->ID ),
						'value' => (string) $page->ID,
					);
				},
				$this->pages
			);
		}

		/**
		 * Returns product attribute options.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function get_product_attributes(): array {
			if ( null === $this->product_attributes ) {
				$this->product_attributes = array_values( wc_get_attribute_taxonomies() );
			}

			return array_map(
				function( $attribute ) {
					return array(
						// translators: %1$s attribute label, %2$s attribute ID.
						'title' => sprintf( esc_html__( '%1$s [%2$s]', 'redparts-sputnik' ), $attribute->attribute_label, $attribute->attribute_id ),
						'value' => $attribute->attribute_name,
					);
				},
				$this->product_attributes
			);
		}
	}
}
