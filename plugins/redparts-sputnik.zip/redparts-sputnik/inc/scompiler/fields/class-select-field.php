<?php
/**
 * Select field.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler\Fields;

use RedParts\Sputnik\Scompiler\Field;
use RedParts\Sputnik\Scompiler\Settings;
use RedParts\Sputnik\Scompiler\Valuable_Field;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Fields\Select_Field' ) ) {
	/**
	 * Class Select_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Select_Field extends Field implements Valuable_Field {
		/**
		 * Returns field ID.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_id(): string {
			return $this->declaration['id'];
		}

		/**
		 * Returns default value.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_default_value(): string {
			return $this->declaration['default'] ?? '';
		}

		/**
		 * Validates field value and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value Field value.
		 *
		 * @return array
		 */
		public function validate( $value ): array {
			$result_value  = $this->get_default_value();
			$result_errors = array();

			if ( is_string( $value ) ) {
				$result_value = $value;
			}

			return array( $result_value, $result_errors );
		}

		/**
		 * Returns normalized version of the field declaration.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function normalize(): array {
			return array_merge(
				$this->declaration,
				array( 'options' => Settings::instance()->normalize_field_options( $this->declaration['options'] ) )
			);
		}
	}
}
