<?php
/**
 * Section field.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler\Fields;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Fields\Section_Field' ) ) {
	/**
	 * Class Section_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Section_Field extends Group_Field { }
}
