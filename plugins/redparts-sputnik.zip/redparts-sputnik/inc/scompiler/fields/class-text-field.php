<?php
/**
 * Text field.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler\Fields;

use RedParts\Sputnik\Scompiler\Field;
use RedParts\Sputnik\Scompiler\Valuable_Field;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Fields\Text_Field' ) ) {
	/**
	 * Class Text_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Text_Field extends Field implements Valuable_Field {
		/**
		 * Returns field ID.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_id(): string {
			return $this->declaration['id'];
		}

		/**
		 * Returns default value.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_default_value(): string {
			return $this->declaration['default'] ?? '';
		}

		/**
		 * Validates field value and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value Field value.
		 *
		 * @return array
		 */
		public function validate( $value ): array {
			$result_value  = $this->get_default_value();
			$result_errors = array();

			if ( is_string( $value ) ) {
				$result_value = $value;

				$validators = $this->declaration['validators'] ?? array();

				foreach ( $validators as $validator ) {
					$validator = explode( ':', $validator );

					if ( 'required' === $validator[0] && empty( $result_value ) ) {
						$result_errors[] = array(
							'path' => array(),
							'text' => esc_html__( 'The field must be filled.', 'redparts-sputnik' ),
						);

						break;
					} elseif ( 'regex' === $validator[0] && 0 === preg_match( $validator[1], $result_value ) ) {
						$result_errors[] = array(
							'path' => array(),
							'text' => esc_html__( 'The field can only contain the following characters: -_a-z.', 'redparts-sputnik' ),
						);

						break;
					}
				}
			} else {
				$result_errors[] = array(
					'path' => array(),
					'text' => esc_html__( 'Invalid value type.', 'redparts-sputnik' ),
				);
			}

			return array( $result_value, $result_errors );
		}
	}
}
