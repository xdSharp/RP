<?php
/**
 * Group field.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler\Fields;

use ErrorException;
use RedParts\Sputnik\Scompiler\Field;
use RedParts\Sputnik\Scompiler\Hierarchical_Field;
use RedParts\Sputnik\Scompiler\Settings;
use RedParts\Sputnik\Scompiler\Valuable_Field;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Fields\Group_Field' ) ) {
	/**
	 * Class Group_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Group_Field extends Field implements Hierarchical_Field {
		/**
		 * Validates field value and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value Field value.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function validate( $value ): array {
			return Settings::instance()->validate_fields( $value, $this->declaration['fields'] );
		}

		/**
		 * Returns normalized version of the field declaration.
		 *
		 * @since 1.17.0
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function normalize(): array {
			return array_merge(
				$this->declaration,
				array( 'fields' => Settings::instance()->normalize_fields( $this->declaration['fields'] ) )
			);
		}

		/**
		 * Returns field by ID.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id Field ID.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return null|Valuable_Field
		 */
		public function get_field_by_id( string $id ): ?Valuable_Field {
			return Settings::instance()->get_field_by_id( $id, $this->declaration['fields'] );
		}
	}
}
