<?php
/**
 * List field.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler\Fields;

use ErrorException;
use RedParts\Sputnik\Scompiler\Field;
use RedParts\Sputnik\Scompiler\Settings;
use RedParts\Sputnik\Scompiler\Valuable_Field;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Fields\List_Field' ) ) {
	/**
	 * Class List_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class List_Field extends Field implements Valuable_Field {
		/**
		 * Returns field ID.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_id(): string {
			return $this->declaration['id'];
		}

		/**
		 * Returns default value.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function get_default_value(): array {
			return $this->declaration['default'] ?? array();
		}

		/**
		 * Validates field value and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value Field value.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function validate( $value ): array {
			$result_value  = $this->get_default_value();
			$result_errors = array();

			if ( is_array( $value ) ) {
				$items        = array_values( $value );
				$result_value = array();

				foreach ( $items as $item_idx => $item ) {
					list( $item_result_value, $item_result_errors ) = Settings::instance()->validate_fields( $item, $this->declaration['fields'] );

					$item_result_errors = Settings::instance()->prepend_path_to_errors( $item_result_errors, array( $item_idx ) );

					$result_value[ $item_idx ] = $item_result_value;
					$result_errors             = array_merge( $result_errors, $item_result_errors );
				}

				$validators = $this->declaration['validators'] ?? array();

				foreach ( $validators as $validator ) {
					$validator = explode( ':', $validator );

					if ( 'unique' === $validator[0] ) {
						$unique_by         = $validator[1];
						$item_idx_by_value = array();

						foreach ( $result_value as $i => $item ) {
							$item_idx_by_value[ $item[ $unique_by ] ]   = $item_idx_by_value[ $item[ $unique_by ] ] ?? array();
							$item_idx_by_value[ $item[ $unique_by ] ][] = $i;
						}

						foreach ( $item_idx_by_value as $item_indexes ) {
							if ( 1 >= count( $item_indexes ) ) {
								continue;
							}

							foreach ( $item_indexes as $item_index ) {
								$result_errors[] = array(
									'path' => array( $item_index, $unique_by ),
									'text' => esc_html__( 'All "Slug" fields must be unique.', 'redparts-sputnik' ),
								);
							}
						}
					}
				}
			}

			return array( $result_value, $result_errors );
		}

		/**
		 * Returns normalized version of the field declaration.
		 *
		 * @since 1.17.0
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function normalize(): array {
			return array_merge(
				$this->declaration,
				array( 'fields' => Settings::instance()->normalize_fields( $this->declaration['fields'] ) )
			);
		}
	}
}
