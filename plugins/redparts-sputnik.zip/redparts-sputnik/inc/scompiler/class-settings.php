<?php
/**
 * RedParts sputnik settings.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler;

use ErrorException;
use RedParts\Sputnik\Scompiler\Fields\List_Field;
use RedParts\Sputnik\Scompiler\Fields\Group_Field;
use RedParts\Sputnik\Scompiler\Fields\Multi_Select_Field;
use RedParts\Sputnik\Scompiler\Fields\Section_Field;
use RedParts\Sputnik\Scompiler\Fields\Select_Field;
use RedParts\Sputnik\Scompiler\Fields\Text_Field;
use RedParts\Sputnik\Singleton;
use RedParts\Sputnik\WPML\WPML;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Settings' ) ) {
	/**
	 * Class Settings.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Settings extends Singleton {
		const OPTION_NAME = 'redparts_sputnik_settings';

		/**
		 * Settings sections.
		 *
		 * @since 1.17.0
		 *
		 * @var array
		 */
		protected $sections = array();

		/**
		 * Registry of field types.
		 *
		 * @since 1.17.0
		 *
		 * @var array
		 */
		protected $field_handlers = array(
			'section'      => Section_Field::class,
			'group'        => Group_Field::class,
			'text'         => Text_Field::class,
			'select'       => Select_Field::class,
			'multi-select' => Multi_Select_Field::class,
			'list'         => List_Field::class,
		);

		/**
		 * Option value.
		 *
		 * @since 1.17.0
		 *
		 * @var array
		 */
		protected $value = array();

		/**
		 * Returns setting value.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id      Setting ID.
		 * @param mixed  $default Default setting value.
		 *
		 * @return mixed
		 */
		public static function get( string $id, $default = null ) {
			$settings = (array) get_option( self::OPTION_NAME, array() );

			if ( isset( $settings[ $id ] ) ) {
				return $settings[ $id ];
			}

			$self = self::instance();

			try {
				$field = $self->get_field_by_id( $id, $self->sections );
			} catch ( ErrorException $error ) {
				return $default;
			}

			if ( $field ) {
				return $field->get_default_value();
			}

			return $default;
		}

		/**
		 * Sets setting value.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id    Setting ID.
		 * @param mixed  $value Setting value.
		 *
		 * @return void
		 */
		public static function set( string $id, $value ): void {
			$settings        = (array) get_option( self::OPTION_NAME, array() );
			$settings[ $id ] = $value;

			update_option( self::OPTION_NAME, $settings );
		}

		/**
		 * Initialization.
		 *
		 * @since 1.17.0
		 */
		public function init() {
			add_action( 'admin_menu', array( $this, 'admin_menu' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
			add_action( 'plugins_loaded', array( $this, 'plugins_loaded' ) );

			if ( ! wp_doing_ajax() ) {
				return;
			}

			add_action( 'wp_ajax_redparts_sputnik_settings_save', array( $this, 'ajax_save' ) );
			add_action( 'wp_ajax_nopriv_redparts_sputnik_settings_save', array( $this, 'ajax_save' ) );
		}

		/**
		 * Runs after plugins loaded.
		 *
		 * @since 1.17.0
		 */
		public function plugins_loaded() {
			$this->sections   = array();
			$this->sections[] = $this->section_social_networks();
			$this->sections[] = $this->section_compare();
			$this->sections[] = $this->section_wishlist();

			if ( class_exists( 'WooCommerce' ) ) {
				$this->sections[] = $this->section_brands();
				$this->sections[] = $this->section_featured_attributes();
				$this->sections[] = $this->section_auto_parts();
			}

			$this->sections[] = $this->section_search();
			$this->sections[] = $this->section_import_export();
		}

		/**
		 * Adds admin menu.
		 *
		 * @since 1.17.0
		 */
		public function admin_menu() {
			add_menu_page(
				esc_html__( 'RedParts Sputnik Settings', 'redparts-sputnik' ),
				esc_html__( 'RedParts Sputnik', 'redparts-sputnik' ),
				'manage_options',
				static::OPTION_NAME,
				array( $this, 'page' ),
				'dashicons-admin-generic'
			);
		}

		/**
		 * Outputs settings page content.
		 *
		 * @since 1.17.0
		 */
		public function page() {
			?>
			<div id="sc-settings"></div>
			<?php
		}

		/**
		 * Enqueue admin scripts.
		 *
		 * @since 1.17.0
		 *
		 * @param string $hook_suffix The current admin page.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 */
		public function enqueue_admin_scripts( string $hook_suffix ) {
			if ( 'toplevel_page_' . static::OPTION_NAME !== $hook_suffix ) {
				return;
			}

			$direction = is_rtl() ? '-rtl' : '-ltr';

			wp_enqueue_style(
				'redparts-sputnik-sc-settings',
				redparts_sputnik()->url( 'assets/vendor/sc-settings/sc-settings' . $direction . '.min.css' ),
				array(),
				redparts_sputnik()::VERSION
			);

			wp_enqueue_script(
				'redparts-sputnik-sc-settings',
				redparts_sputnik()->url( 'assets/vendor/sc-settings/sc-settings.js' ),
				array( 'wp-i18n', 'js-base64', 'papaparse', 'react', 'react-dom' ),
				redparts_sputnik()::VERSION,
				true
			);

			$sections = $this->normalize_fields( $this->sections );

			list( $value ) = $this->validate_fields(
				get_option( self::OPTION_NAME ),
				$sections
			);

			$options = array(
				'optionName' => static::OPTION_NAME,
				'title'      => esc_html__( 'RedParts Sputnik', 'redparts-sputnik' ),
				// translators: %s plugin version.
				'subtitle'   => sprintf( esc_html__( 'Version %s', 'redparts-sputnik' ), redparts_sputnik()::VERSION ),
				'sections'   => $sections,
				'value'      => $value,
				'ajax'       => array(
					'save' => array(
						'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
						'nonce' => wp_create_nonce( 'redparts_sputnik_settings_save' ),
					),
				),
				'i18n'       => array(
					'button_save'              => esc_html__( 'Save', 'redparts-sputnik' ),
					'alert_saved_successfully' => esc_html__( 'Settings saved successfully!', 'redparts-sputnik' ),
					'alert_save_error'         => esc_html__( 'An error occurred while saving the settings!', 'redparts-sputnik' ),
				),
			);

			$script = '
			const element = document.querySelector(\'#sc-settings\');

			if (element) {
				scompilerSettings(element, ' . wp_json_encode( $options ) . ');
			}
			';

			wp_add_inline_script( 'redparts-sputnik-sc-settings', $script );
		}


		/**
		 * Saves settings.
		 *
		 * @since 1.17.0
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 */
		public function ajax_save() {
			WPML::switch_ajax_language();

			if (
				! isset( $_POST['nonce'] ) ||
				! wp_verify_nonce(
					sanitize_key( wp_unslash( $_POST['nonce'] ) ),
					'redparts_sputnik_settings_save'
				)
			) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Action failed. Please refresh the page and retry.', 'redparts-sputnik' ),
					)
				);
			}

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'You do not have permission to manage options.', 'redparts-sputnik' ),
					)
				);
			}

			if ( ! isset( $_POST['data'] ) ) {
				wp_send_json_error(
					array(
						'message' => esc_html__( 'Data required.', 'redparts-sputnik' ),
					)
				);
			}

			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$data = json_decode( wp_unslash( $_POST['data'] ), true, 32 );

			if ( JSON_ERROR_NONE !== json_last_error() ) {
				wp_send_json_error(
					array(
						// translators: %s error code.
						'message' => sprintf( esc_html__( 'Invalid data (code %s).', 'redparts-sputnik' ), json_last_error() ),
					)
				);
			}

			$sections = $this->normalize_fields( $this->sections );

			list( $value, $errors ) = $this->validate_fields( $data, $sections );

			if ( ! empty( $errors ) ) {
				wp_send_json_error(
					array(
						'errors' => $errors,
					)
				);
			}

			update_option( self::OPTION_NAME, $value );

			wp_send_json_success( $value );
		}

		/**
		 * Returns field by ID.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id     Field ID.
		 * @param array  $fields Array of field declarations.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return Valuable_Field|null
		 */
		public function get_field_by_id( string $id, array $fields ): ?Valuable_Field {
			foreach ( $fields as $field ) {
				$handler = $this->get_field_handler( $field );

				if ( $handler instanceof Valuable_Field ) {
					if ( $id === $handler->get_id() ) {
						return $handler;
					}
				} elseif ( $handler instanceof Hierarchical_Field ) {
					$field = $handler->get_field_by_id( $id );

					if ( null !== $field ) {
						return $field;
					}
				}
			}

			return null;
		}

		/**
		 * Validate fields and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value  Value.
		 * @param array $fields Fields array.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function validate_fields( $value, array $fields ): array {
			$value = is_array( $value ) ? $value : array();

			$result_value  = array();
			$result_errors = array();

			foreach ( $fields as $field ) {
				$handler = $this->get_field_handler( $field );

				if ( $handler instanceof Valuable_Field ) {
					$field_value = $value[ $handler->get_id() ] ?? $handler->get_default_value();
				} else {
					$field_value = $value;
				}

				list( $field_value, $field_errors ) = $handler->validate( $field_value );

				if ( $handler instanceof Valuable_Field ) {
					$field_value  = array( $handler->get_id() => $field_value );
					$field_errors = $this->prepend_path_to_errors( $field_errors, array( $handler->get_id() ) );
				}

				$result_value  = array_merge( $result_value, $field_value );
				$result_errors = array_merge( $result_errors, $field_errors );
			}

			return array( $result_value, $result_errors );
		}

		/**
		 * Returns normalized version of the field declarations.
		 *
		 * @since 1.17.0
		 *
		 * @param array $fields Array of field declarations.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return array
		 */
		public function normalize_fields( array $fields ): array {
			$result_fields = array();

			foreach ( $fields as $field ) {
				$result_fields[] = $this->get_field_handler( $field )->normalize();
			}

			return $result_fields;
		}

		/**
		 * Returns normalized options array.
		 *
		 * @since 1.17.0
		 *
		 * @param array $options Field options.
		 *
		 * @return array
		 */
		public function normalize_field_options( array $options ): array {
			$result_options = array();

			foreach ( $options as $index => $option ) {
				if ( is_array( $option ) ) {
					$result_options[] = $option;
				} elseif ( is_string( $index ) && is_string( $option ) ) {
					$result_options[] = array(
						'title' => $option,
						'value' => $index,
					);
				} elseif ( is_int( $index ) && 'menus' === $option ) {
					$result_options = array_merge( $result_options, Data::instance()->get_menus() );
				} elseif ( is_int( $index ) && 'pages' === $option ) {
					$result_options = array_merge( $result_options, Data::instance()->get_pages() );
				} elseif ( is_int( $index ) && 'product_attributes' === $option ) {
					$result_options = array_merge( $result_options, Data::instance()->get_product_attributes() );
				}
			}

			return $result_options;
		}

		/**
		 * Returns field handler.
		 *
		 * @since 1.17.0
		 *
		 * @param array $declaration Field declaration.
		 *
		 * @throws ErrorException Thrown when field handler not found.
		 *
		 * @return Field
		 */
		public function get_field_handler( array $declaration ): Field {
			$handler = $this->field_handlers[ $declaration['type'] ] ?? Field::class;

			if ( Field::class !== $handler && ! is_subclass_of( $handler, Field::class ) ) {
				throw new ErrorException( 'Field handler should be based on \'' . Field::class . '\'.' );
			}

			return new $handler( $declaration );
		}

		/**
		 * Prepends specified path to errors.
		 *
		 * @since 1.17.0
		 *
		 * @param array $errors       Errors array.
		 * @param array $prepend_path Path to prepend.
		 *
		 * @return array
		 */
		public function prepend_path_to_errors( array $errors, array $prepend_path ): array {
			foreach ( array_keys( $errors ) as $error_idx ) {
				$errors[ $error_idx ]['path'] = array_merge(
					$prepend_path,
					$errors[ $error_idx ]['path']
				);
			}

			return $errors;
		}

		/**
		 * Returns the declaration of the settings for the 'Social Networks' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_social_networks(): array {
			return array(
				'type'   => 'section',
				'id'     => 'section_social_networks',
				'title'  => esc_html__( 'Social Networks', 'redparts-sputnik' ),
				'fields' => array(
					array(
						'id'       => 'social_links_menu',
						'type'     => 'select',
						'title'    => esc_html__( 'Social Links Menu', 'redparts-sputnik' ),
						'subtitle' => esc_html__( 'Select the WordPress menu that will be responsible for displaying social links.', 'redparts-sputnik' ),
						'options'  => array(
							'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
							'menus',
						),
					),
					array(
						'id'       => 'share_buttons_menu',
						'type'     => 'select',
						'title'    => esc_html__( 'Share Buttons Menu', 'redparts-sputnik' ),
						'subtitle' => esc_html__( 'Select the WordPress menu that will be responsible for displaying share buttons.', 'redparts-sputnik' ),
						'options'  => array(
							'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
							'menus',
						),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Compare' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_compare(): array {
			$compare_rows_default_value = implode(
				', ',
				array(
					'rating',
					'availability',
					'price',
					'add_to_cart',
					'sku',
					'weight',
					'dimensions',
					'attributes',
				)
			);

			return array(
				'type'   => 'section',
				'id'     => 'section_compare',
				'title'  => esc_html__( 'Compare', 'redparts-sputnik' ),
				'fields' => array(
					array(
						'type'    => 'select',
						'id'      => 'compare_enabled',
						'title'   => esc_html__( 'Enabled', 'redparts-sputnik' ),
						'options' => array(
							'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
							'no'  => esc_html__( 'No', 'redparts-sputnik' ),
						),
						'default' => 'yes',
					),
					array(
						'type'      => 'group',
						'condition' => array( '=', 'field:compare_enabled', 'value:yes' ),
						'fields'    => array(
							array(
								'type'    => 'select',
								'id'      => 'compare_page',
								'title'   => esc_html__( 'Compare Page', 'redparts-sputnik' ),
								'options' => array(
									'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
									'pages',
								),
							),
							array(
								'type'     => 'text',
								'id'       => 'compare_rows',
								'title'    => esc_html__( 'Rows', 'redparts-sputnik' ),
								// translators: %s list of possible values.
								'subtitle' => sprintf( esc_html__( 'A comma-separated names of the rows to be displayed in the comparison table. Possible values: %s', 'redparts-sputnik' ), $compare_rows_default_value ),
								'default'  => $compare_rows_default_value,
								'rows'     => 3,
							),
							array(
								'type'     => 'text',
								'id'       => 'compare_excluded_attributes',
								'title'    => esc_html__( 'Excluded attributes', 'redparts-sputnik' ),
								'subtitle' => esc_html__( 'A comma-separated list of product attribute slugs that should not appear in the comparison table.', 'redparts-sputnik' ),
								'rows'     => 3,
							),
						),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Wishlist' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_wishlist(): array {
			return array(
				'type'   => 'section',
				'id'     => 'section_wishlist',
				'title'  => esc_html__( 'Wishlist', 'redparts-sputnik' ),
				'fields' => array(
					array(
						'type'    => 'select',
						'id'      => 'wishlist_enabled',
						'title'   => esc_html__( 'Enabled', 'redparts-sputnik' ),
						'options' => array(
							'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
							'no'  => esc_html__( 'No', 'redparts-sputnik' ),
						),
						'default' => 'yes',
					),
					array(
						'type'      => 'select',
						'condition' => array( '=', 'field:wishlist_enabled', 'value:yes' ),
						'id'        => 'wishlist_page',
						'title'     => esc_html__( 'Wishlist Page', 'redparts-sputnik' ),
						'options'   => array(
							'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
							'pages',
						),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Brands' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_brands(): array {
			return array(
				'type'   => 'section',
				'id'     => 'section_brands',
				'title'  => esc_html__( 'Brands', 'redparts-sputnik' ),
				'fields' => array(
					array(
						'type'    => 'select',
						'id'      => 'brand_attribute',
						'title'   => esc_html__( 'Brand Attribute', 'redparts-sputnik' ),
						'options' => array(
							'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
							'product_attributes',
						),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Featured Attributes' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_featured_attributes(): array {
			return array(
				'type'   => 'section',
				'id'     => 'section_featured_attributes',
				'title'  => esc_html__( 'Featured Attributes', 'redparts-sputnik' ),
				'fields' => array(
					array(
						'type'    => 'multi-select',
						'id'      => 'global_featured_attributes',
						'title'   => esc_html__( 'Global featured attributes', 'redparts-sputnik' ),
						'options' => array( 'product_attributes' ),
						'default' => array(),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Auto Parts' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_auto_parts(): array {
			$autoparts_features = array(
				'type'     => 'select',
				'id'       => 'autoparts_features',
				'title'    => esc_html__( 'Use auto parts store features', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Garage, parts finder block, compatibility badge, etc. Set to "no" if you are not going to sell auto parts.', 'redparts-sputnik' ),
				'options'  => array(
					'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
					'no'  => esc_html__( 'No', 'redparts-sputnik' ),
				),
				'default'  => 'yes',
			);

			$garage_page = array(
				'type'    => 'select',
				'id'      => 'garage_page',
				'title'   => esc_html__( 'Show garage page in my account', 'redparts-sputnik' ),
				'options' => array(
					'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
					'no'  => esc_html__( 'No', 'redparts-sputnik' ),
				),
				'default' => 'yes',
			);

			$vehicle_attribute = array(
				'type'    => 'select',
				'id'      => 'vehicle_attribute',
				'title'   => esc_html__( 'Vehicle Attribute', 'redparts-sputnik' ),
				'options' => array(
					'' => esc_html__( '[Not selected]', 'redparts-sputnik' ),
					'product_attributes',
				),
			);

			$search_vehicles_by_vin = array(
				'type'     => 'select',
				'id'       => 'search_vehicles_by_vin',
				'title'    => esc_html__( 'Search vehicles by VIN', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Enables or disables the ability to search for vehicles by VIN.', 'redparts-sputnik' ),
				'options'  => array(
					'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
					'no'  => esc_html__( 'No', 'redparts-sputnik' ),
				),
				'default'  => 'no',
			);

			$vehicle_fields = array(
				'type'       => 'list',
				'id'         => 'vehicle_fields',
				'title'      => esc_html__( 'Vehicle Fields', 'redparts-sputnik' ),
				'strings'    => array(
					'add'                 => esc_html__( 'Add Field', 'redparts-sputnik' ),
					'remove'              => esc_html__( 'Remove', 'redparts-sputnik' ),
					'up'                  => esc_html__( 'Up', 'redparts-sputnik' ),
					'down'                => esc_html__( 'Down', 'redparts-sputnik' ),
					// translators: %s field number.
					'item_title'          => esc_html__( 'Field #%s', 'redparts-sputnik' ),
					'remove_confirmation' => esc_html__( 'Are you sure you want to delete this field?', 'redparts-sputnik' ),
				),
				'item_title' => 'label',
				'fields'     => array(
					array(
						'type'    => 'select',
						'id'      => 'type',
						'title'   => esc_html__( 'Type', 'redparts-sputnik' ),
						'options' => array(
							'text' => esc_html__( 'Text', 'redparts-sputnik' ),
							'year' => esc_html__( 'Year', 'redparts-sputnik' ),
						),
						'default' => 'text',
					),
					array(
						'type'    => 'select',
						'id'      => 'order',
						'title'   => esc_html__( 'Options order', 'redparts-sputnik' ),
						'options' => array(
							'ask'  => esc_html__( 'Ascending', 'redparts-sputnik' ),
							'desk' => esc_html__( 'Descending', 'redparts-sputnik' ),
						),
						'default' => 'ask',
					),
					array(
						'type'       => 'text',
						'id'         => 'slug',
						'title'      => esc_html__( 'Slug', 'redparts-sputnik' ),
						'validators' => array( 'required', 'regex:/^[-_a-z]+$/' ),
					),
					array(
						'type'       => 'text',
						'id'         => 'label',
						'title'      => esc_html__( 'Label', 'redparts-sputnik' ),
						'validators' => array( 'required' ),
					),
					array(
						'type'       => 'text',
						'id'         => 'placeholder',
						'title'      => esc_html__( 'Placeholder', 'redparts-sputnik' ),
						'validators' => array( 'required' ),
					),
				),
				'validators' => array(
					'unique:slug',
				),
			);

			$vehicle_name = array(
				'type'    => 'text',
				'id'      => 'vehicle_name',
				'title'   => esc_html__( 'Vehicle Name', 'redparts-sputnik' ),
				'default' => '%produced_since% %brand% %model%',
			);

			$vehicle_description = array(
				'type'    => 'text',
				'id'      => 'vehicle_description',
				'title'   => esc_html__( 'Vehicle Description', 'redparts-sputnik' ),
				'default' => '%modification%',
			);

			$vehicle_import = array(
				'type'  => 'vehicle_import',
				'title' => esc_html__( 'Import Vehicles', 'redparts-sputnik' ),
				'ajax'  => array(
					'import' => array(
						'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
						'nonce' => wp_create_nonce( 'redparts_sputnik_vehicles_import' ),
					),
					'clear'  => array(
						'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
						'nonce' => wp_create_nonce( 'redparts_sputnik_vehicles_clear' ),
					),
				),
				'i18n'  => array(
					'label_clear'             => esc_html__( 'Clear existing data before import', 'redparts-sputnik' ),
					'button_import'           => esc_html__( 'Import', 'redparts-sputnik' ),
					'button_cancel'           => esc_html__( 'Cancel', 'redparts-sputnik' ),
					'button_continue'         => esc_html__( 'Continue', 'redparts-sputnik' ),
					// translators: %1$s line number, %2$s log message.
					'text_log_message'        => esc_html__( 'Line #%1$s: %2$s', 'redparts-sputnik' ),
					'text_clear_in_progress'  => esc_html__( 'Clear data in progress...', 'redparts-sputnik' ),
					'text_import_in_progress' => esc_html__( 'Import in progress...', 'redparts-sputnik' ),
					'text_import_completed'   => esc_html__( 'Import completed successfully.', 'redparts-sputnik' ),
					'confirm_clear'           => esc_html__( 'Are you sure you want to delete all vehicles and compatibility data before import?', 'redparts-sputnik' ),
				),
			);

			$vehicle_export = array(
				'type'  => 'vehicle_export',
				'title' => esc_html__( 'Export Vehicles', 'redparts-sputnik' ),
				'ajax'  => array(
					'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
					'nonce' => wp_create_nonce( 'redparts_sputnik_vehicles_export' ),
				),
				'i18n'  => array(
					'label_include_compatibility' => esc_html__( 'Include compatibility information', 'redparts-sputnik' ),
					'button_export'               => esc_html__( 'Export', 'redparts-sputnik' ),
					'button_cancel'               => esc_html__( 'Cancel', 'redparts-sputnik' ),
					'button_continue'             => esc_html__( 'Continue', 'redparts-sputnik' ),
					'text_in_progress'            => esc_html__( 'Export in progress...', 'redparts-sputnik' ),
					// translators: %s file name.
					'link_download'               => esc_html__( 'Download %s', 'redparts-sputnik' ),
				),
			);

			$vehicle_picker_group_same_values = array(
				'type'     => 'select',
				'id'       => 'vehicle_picker_group_same_values',
				'title'    => esc_html__( 'Group duplicate values in the last field of the vehicle picker', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Deprecated. Should always be "Yes".', 'redparts-sputnik' ),
				'options'  => array(
					'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
					'no'  => esc_html__( 'No', 'redparts-sputnik' ),
				),
				'default'  => 'yes',
			);

			return array(
				'type'   => 'section',
				'id'     => 'section_auto_parts',
				'title'  => esc_html__( 'Auto Parts', 'redparts-sputnik' ),
				'fields' => array(
					$autoparts_features,
					array(
						'type'      => 'group',
						'condition' => array( '=', 'field:autoparts_features', 'value:yes' ),
						'fields'    => array(
							$garage_page,
							$vehicle_attribute,
							$search_vehicles_by_vin,
							$vehicle_fields,
							$vehicle_name,
							$vehicle_description,
							$vehicle_import,
							$vehicle_export,
							$vehicle_picker_group_same_values,
						),
					),
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Search' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_search(): array {
			$search_by_sku = array(
				'type'    => 'select',
				'id'      => 'search_by_sku',
				'title'   => esc_html__( 'Search products by SKU', 'redparts-sputnik' ),
				'options' => array(
					'yes' => esc_html__( 'Yes', 'redparts-sputnik' ),
					'no'  => esc_html__( 'No', 'redparts-sputnik' ),
				),
				'default' => 'yes',
			);

			$search_by_sku_match = array(
				'type'      => 'select',
				'condition' => array( '=', 'field:search_by_sku', 'value:yes' ),
				'id'        => 'search_by_sku_match',
				'title'     => esc_html__( 'Search products by SKU (match type)', 'redparts-sputnik' ),
				'options'   => array(
					'exactly'  => esc_html__( 'Exactly matches the search term', 'redparts-sputnik' ),
					'starts'   => esc_html__( 'Starts with the search term', 'redparts-sputnik' ),
					'contains' => esc_html__( 'Contains the search term', 'redparts-sputnik' ),
				),
				'default'   => 'exactly',
			);

			$search_by_attributes = array(
				'type'     => 'multi-select',
				'id'       => 'search_by_attributes',
				'title'    => esc_html__( 'Search products by attributes (name exactly matches the search term)', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Select the attributes that will be included in the search. Only those attributes will be found whose name exactly matches the search term.', 'redparts-sputnik' ),
				'options'  => array( 'product_attributes' ),
				'default'  => array(),
			);

			$search_by_attributes_starts = array(
				'type'     => 'multi-select',
				'id'       => 'search_by_attributes_starts',
				'title'    => esc_html__( 'Search products by attributes (name starts with the search term)', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Select the attributes that will be included in the search. Only those attributes will be found whose name starts with the search term.', 'redparts-sputnik' ),
				'options'  => array( 'product_attributes' ),
				'default'  => array(),
			);

			$search_by_attributes_contains = array(
				'type'     => 'multi-select',
				'id'       => 'search_by_attributes_contains',
				'title'    => esc_html__( 'Search products by attributes (name contains the search term)', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Select the attributes that will be included in the search. Only those attributes will be found whose name contains the search term.', 'redparts-sputnik' ),
				'options'  => array( 'product_attributes' ),
				'default'  => array(),
			);

			$search_index = array(
				'id'       => 'search_index',
				'type'     => 'search_index',
				'title'    => esc_html__( 'Search Index', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'Currently used only for searching products by SKU.', 'redparts-sputnik' ),
				'ajax'     => array(
					'status' => array(
						'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
						'nonce' => wp_create_nonce( 'redparts_sputnik_search_index_status' ),
					),
					'clear'  => array(
						'url'   => apply_filters( 'redparts_sputnik_ajax_url', '' ),
						'nonce' => wp_create_nonce( 'redparts_sputnik_search_clear_index' ),
					),
				),
				'i18n'     => array(
					'button_rebuild_index' => esc_html__( 'Rebuild Index', 'redparts-sputnik' ),
					'text_loading'         => esc_html__( 'Loading...', 'redparts-sputnik' ),
					'text_note'            => esc_html__( 'After clicking on the button, the index will be deleted and the indexing process will start over. Depending on the number of products, indexing can take quite a long time. You can close the page and indexing will continue in the background.', 'redparts-sputnik' ),
					'confirm_clear'        => esc_html__( 'Are you sure you want to rebuild the index?', 'redparts-sputnik' ),
				),
			);

			return array(
				'type'     => 'section',
				'id'       => 'section_search',
				'title'    => esc_html__( 'Search', 'redparts-sputnik' ),
				'subtitle' => esc_html__( 'The search enhancements presented in this section do not currently use a specialized index table, so they can significantly slow down the search. Use these opportunities at your own risk.', 'redparts-sputnik' ),
				'fields'   => array(
					$search_by_sku,
					$search_by_sku_match,
					$search_by_attributes,
					$search_by_attributes_starts,
					$search_by_attributes_contains,
					$search_index,
				),
			);
		}

		/**
		 * Returns the declaration of the settings for the 'Import / Export' section.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function section_import_export(): array {
			$search_import_options = array(
				'type'  => 'import_options',
				'id'    => 'import_options',
				'title' => esc_html__( 'Import Options', 'redparts-sputnik' ),
				'i18n'  => array(
					'button_import'               => esc_html__( 'Import', 'redparts-sputnik' ),
					'label_import_from_file'      => esc_html__( 'Import from file', 'redparts-sputnik' ),
					'label_import_from_clipboard' => esc_html__( 'Import from clipboard', 'redparts-sputnik' ),
					'confirm_import'              => esc_html__( 'Are you sure you want to import options?', 'redparts-sputnik' ),
					'alert_import_successful'     => esc_html__( 'Import completed successfully!', 'redparts-sputnik' ),
					'alert_import_failure'        => esc_html__( 'An error occurred during import!', 'redparts-sputnik' ),
				),
			);
			$search_export_options = array(
				'type'  => 'export_options',
				'id'    => 'export_options',
				'title' => esc_html__( 'Export Options', 'redparts-sputnik' ),
				'i18n'  => array(
					'button_export_to_file'    => esc_html__( 'Export to file', 'redparts-sputnik' ),
					'button_copy_to_clipboard' => esc_html__( 'Copy to clipboard', 'redparts-sputnik' ),
					'alert_options_copied'     => esc_html__( 'Options copied to clipboard!', 'redparts-sputnik' ),
				),
			);

			return array(
				'type'   => 'section',
				'id'     => 'section_import_export',
				'title'  => esc_html__( 'Import / Export', 'redparts-sputnik' ),
				'fields' => array(
					$search_import_options,
					$search_export_options,
				),
			);
		}
	}
}
