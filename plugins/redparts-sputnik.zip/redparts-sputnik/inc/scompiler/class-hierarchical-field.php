<?php
/**
 * Hierarchical field interface.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler;

defined( 'ABSPATH' ) || exit;

if ( ! interface_exists( 'RedParts\Sputnik\Scompiler\Hierarchical_Field' ) ) {
	/**
	 * Interface Hierarchical_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	interface Hierarchical_Field {
		/**
		 * Returns field by ID.
		 *
		 * @since 1.17.0
		 *
		 * @param string $id Field ID.
		 *
		 * @return null|Valuable_Field
		 */
		public function get_field_by_id( string $id ): ?Valuable_Field;
	}
}
