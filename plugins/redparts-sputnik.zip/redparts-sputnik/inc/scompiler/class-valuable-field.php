<?php
/**
 * Valuable field interface.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler;

defined( 'ABSPATH' ) || exit;

if ( ! interface_exists( 'RedParts\Sputnik\Scompiler\Valuable_Field' ) ) {
	/**
	 * Interface Valuable_Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	interface Valuable_Field {
		/**
		 * Returns field ID.
		 *
		 * @since 1.17.0
		 *
		 * @return string
		 */
		public function get_id(): string;

		/**
		 * Returns default value.
		 *
		 * @since 1.17.0
		 *
		 * @return mixed
		 */
		public function get_default_value();
	}
}
