<?php
/**
 * Base field class.
 *
 * @package RedParts\Sputnik
 * @since 1.17.0
 */

namespace RedParts\Sputnik\Scompiler;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'RedParts\Sputnik\Scompiler\Field' ) ) {
	/**
	 * Class Field.
	 *
	 * @package RedParts\Sputnik
	 * @since 1.17.0
	 */
	class Field {
		/**
		 * Field declaration.
		 *
		 * @since 1.17.0
		 *
		 * @var array
		 */
		protected $declaration;

		/**
		 * Field constructor.
		 *
		 * @since 1.17.0
		 *
		 * @param array $declaration Field declaration data.
		 */
		public function __construct( array $declaration ) {
			$this->declaration = $declaration;
		}

		/**
		 * Validates field value and returns a pair of array with value and array of errors.
		 *
		 * @since 1.17.0
		 *
		 * @param mixed $value Field value.
		 *
		 * @return array
		 */
		public function validate( $value ): array {
			return array( array(), array() );
		}

		/**
		 * Returns normalized version of the field declaration.
		 *
		 * @since 1.17.0
		 *
		 * @return array
		 */
		public function normalize(): array {
			return $this->declaration;
		}
	}
}
